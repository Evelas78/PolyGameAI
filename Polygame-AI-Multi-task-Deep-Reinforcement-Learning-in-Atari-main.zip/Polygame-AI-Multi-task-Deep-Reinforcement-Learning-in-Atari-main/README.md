# Polygame-AI-Multi-task-Deep-Reinforcement-Learning-in-Atari
This research aims to explore the field of Multi-Task Reinforcement Learning. With a slight modification to the Deep Q-Network algorithm, Polygame AI is capable of learning to play several Atari games. Future work involves scaling our algorithm up to a more complex and diverse set of tasks.
